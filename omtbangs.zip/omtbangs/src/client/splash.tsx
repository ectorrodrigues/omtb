import './index.css';

import React, { useState } from "react";

export default function RedditPosts() {
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function fetchPosts() {
    setLoading(true);
    setError("");
    setPosts([]);

    const url =
      "https://www.reddit.com/r/obscuremusicthatbangs/new.json?limit=100";

    try {
      const response = await fetch(url, {
        headers: {
          Accept: "application/json"
        }
      });

      if (!response.ok) {
        throw new Error(`Reddit returned HTTP ${response.status}`);
      }

      const json = await response.json();
      const children = json?.data?.children ?? [];

      setPosts(
        children.map(({ data }) => ({
          id: data.id,
          title: data.title,
          url: data.url,
          permalink: `https://www.reddit.com${data.permalink}`,
          author: data.author
        }))
      );

    } catch (err) {
      setError(
        `${err.message}. Reddit may block this request through HTTP 403 or CORS.`
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <button onClick={fetchPosts} disabled={loading}>
        {loading ? "Loading..." : "Fetch Reddit Posts"}
      </button>

      {error && <p style={{ color: "red" }}>{error}</p>}

      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <a
              href={post.permalink}
              target="_blank"
              rel="noreferrer"
            >
              {post.title}
            </a>
            <br />
            <small>By {post.author}</small>
            <br />
            <a href={post.url} target="_blank" rel="noreferrer">
              Open music link
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
