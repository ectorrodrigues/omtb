<?php
// Save as /home/YOUR_CPANEL_USER/omtb-db.php, outside public_html.
return [
    'dsn' => 'mysql:host=localhost;dbname=raqu9294_omtb;charset=utf8mb4',
    'user' => 'raqu9294_omtb',
    'password' => 'SET_THE_DATABASE_PASSWORD_HERE',
];
