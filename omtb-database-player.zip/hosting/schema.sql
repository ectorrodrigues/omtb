CREATE TABLE IF NOT EXISTS omtb_videos (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  url TEXT NOT NULL,
  url_hash BINARY(32) NOT NULL,
  title TEXT NOT NULL,
  reddit_id VARCHAR(100) NOT NULL,
  author_name VARCHAR(100) NOT NULL,
  permalink TEXT NOT NULL,
  thumbnail TEXT NULL,
  video_json JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY unique_video_url (url_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
