<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}
require __DIR__ . '/feed.php';
try {
    // Keep this file outside public_html; never put passwords in browser assets.
    $configPath = getenv('OMTB_CONFIG') ?: dirname(__DIR__, 4) . '/omtb-db.php';
    if (!is_file($configPath)) throw new RuntimeException('Missing database configuration');
    $config = require $configPath;
    $db = new PDO($config['dsn'], $config['user'], $config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $warning = null;
    $inserted = 0;
    try {
        $inserted = importPosts($db, fetchRedditPosts());
    } catch (Throwable $e) {
        error_log('OMTB sync: ' . $e->getMessage());
        $warning = 'Reddit could not be synced. Showing saved videos.';
    }
    $posts = [];
    foreach ($db->query('SELECT * FROM omtb_videos ORDER BY id DESC') as $row) {
        $posts[] = ['id' => (string)$row['id'], 'title' => $row['title'], 'url' => $row['url'], 'authorName' => $row['author_name'], 'permalink' => $row['permalink'], 'thumbnail' => $row['thumbnail'], 'createdAt' => $row['created_at'], 'video' => json_decode($row['video_json'], true, 512, JSON_THROW_ON_ERROR)];
    }
    echo json_encode(['posts' => $posts, 'inserted' => $inserted, 'warning' => $warning], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    error_log('OMTB playlist: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['error' => 'The playlist database is temporarily unavailable.']);
}
