<?php
declare(strict_types=1);

function videoSource(array $post): ?array {
    $raw = $post['url'] ?? '';
    if (!is_string($raw)) return null;
    $url = parse_url($raw);
    if (!$url || ($url['scheme'] ?? '') !== 'https' || isset($url['user']) || isset($url['pass'])) return null;
    $host = strtolower($url['host'] ?? '');
    $path = $url['path'] ?? '';
    $parts = explode('/', $path);
    $id = null;
    if ($host === 'youtu.be') $id = $parts[1] ?? null;
    if (in_array($host, ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'www.youtube-nocookie.com'], true)) {
        parse_str($url['query'] ?? '', $query);
        $id = $path === '/watch' ? ($query['v'] ?? null) : (in_array($parts[1] ?? '', ['embed', 'shorts', 'live'], true) ? ($parts[2] ?? null) : null);
    }
    if (is_string($id) && preg_match('/^[\w-]{11}$/D', $id)) return ['kind' => 'youtube', 'id' => $id];
    $media = $post['secure_media']['reddit_video'] ?? null;
    if (is_array($media) && empty($media['is_gif']) && is_string($media['hls_url'] ?? null)) {
        $hls = html_entity_decode($media['hls_url'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (parse_url($hls, PHP_URL_SCHEME) === 'https' && parse_url($hls, PHP_URL_HOST) === 'v.redd.it') return ['kind' => 'video', 'url' => $hls, 'format' => 'hls'];
    }
    if (preg_match('/\.(mp4|webm|m3u8)$/i', $path)) return ['kind' => 'video', 'url' => $raw, 'format' => preg_match('/\.m3u8$/i', $path) ? 'hls' : 'file'];
    return null;
}

function fetchRedditPosts(): array {
    $curl = curl_init('https://www.reddit.com/r/obscuremusicthatbangs/new.json?limit=100&raw_json=1');
    curl_setopt_array($curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 12, CURLOPT_USERAGENT => 'OMTBPlaylist/1.0 (raquelprada.com)', CURLOPT_HTTPHEADER => ['Accept: application/json']]);
    $body = curl_exec($curl);
    $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($body === false || $status !== 200) throw new RuntimeException('Reddit feed unavailable (HTTP ' . $status . ')');
    $data = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
    if (!isset($data['data']['children']) || !is_array($data['data']['children'])) throw new RuntimeException('Invalid Reddit feed');
    return array_slice($data['data']['children'], 0, 100);
}

function importPosts(PDO $db, array $children): int {
    $exists = $db->prepare('SELECT id FROM omtb_videos WHERE url_hash = UNHEX(SHA2(?, 256))');
    $insert = $db->prepare('INSERT INTO omtb_videos (url, url_hash, title, reddit_id, author_name, permalink, thumbnail, video_json) VALUES (?, UNHEX(SHA2(?, 256)), ?, ?, ?, ?, ?, ?)');
    $count = 0;
    // Oldest first gives the newest discoveries the highest IDs.
    foreach (array_reverse($children) as $child) {
        $post = $child['data'] ?? null;
        if (!is_array($post) || !is_string($post['title'] ?? null) || !is_string($post['id'] ?? null)) continue;
        $video = videoSource($post);
        if (!$video) continue;
        $url = $video['kind'] === 'youtube' ? 'https://www.youtube.com/watch?v=' . $video['id'] : $video['url'];
        $exists->execute([$url]);
        if ($exists->fetchColumn() !== false) continue;
        try {
            $insert->execute([$url, $url, $post['title'], substr($post['id'], 0, 100), substr($post['author'] ?? 'unknown', 0, 100), $post['permalink'] ?? '/r/obscuremusicthatbangs/', isset($post['thumbnail']) && str_starts_with($post['thumbnail'], 'https://') ? $post['thumbnail'] : null, json_encode($video, JSON_THROW_ON_ERROR)]);
            $count++;
        } catch (PDOException $e) {
            // A competing request may have inserted this URL after our check.
            if (($e->errorInfo[1] ?? null) !== 1062) throw $e;
        }
    }
    return $count;
}
