# raquelprada.com database player

Destination: `https://raquelprada.com/resources/omtb/player/`

The player requests `playlist.php` on each visit and refresh. PHP fetches the latest 100 posts from r/obscuremusicthatbangs, imports supported videos, then returns the saved MySQL playlist ordered newest first. Credentials stay in a PHP configuration file outside the document root.

## Deployment

1. Hosting needs PHP 8.0+ with PDO MySQL and cURL.
2. Run `hosting/schema.sql` in `raqu9294_omtb` once. This creates `omtb_videos` without changing other tables. This table has already been created on the provided HostGator database.
3. Copy `hosting/omtb-db.example.php` to `/home/raqu9294/omtb-db.php`, fill in the database password, and restrict permissions to 600. Use `localhost` for MySQL on this HostGator account. An alternative config path can be set with `OMTB_CONFIG`.
4. Run `npm run build:hosted`. Upload the contents of `dist/hosted/` to `public_html/resources/omtb/player/`, including both PHP files and assets. Upload the new index last. Preserve existing assets until the update is verified.
5. Check `playlist.php`: expect a JSON `posts` array, `inserted` count and optional `warning`. Request again and confirm duplicates are not inserted. Open the player and test playback and Next.

## Storage and sync

`omtb_videos` stores an auto-increment ID, video URL, title, Reddit metadata and playback source. YouTube URLs are normalized to their canonical watch URL, so shortened links and tracking parameters do not create duplicates. Reddit videos retain their audio-inclusive HLS URL. Direct MP4, WebM and HLS videos are supported.

The importer checks a SHA-256 URL key before insertion; a unique index protects against simultaneous inserts. Duplicates are skipped without changing saved titles. The complete stored queue is returned. Existing Reddit handoff links select the requested video if already saved; they do not insert fragment data.

A failed Reddit fetch leaves saved tracks available and returns a warning. An empty database cannot play until an import succeeds. Reddit may reject anonymous JSON requests from hosting providers; HTTP 403/429 may require an approved Reddit API authentication setup. Errors are logged server-side without exposing credentials in responses.

## Checks

- `npm run test:types`
- `npm run lint`
- `npm run test:unit`
- `php tests/playlist.test.php`
- Optional remote integration: set `OMTB_TEST_PASSWORD` in your environment and run the PHP test. It uses a temporary table that disappears on disconnect; production records are untouched.

YouTube embedding and mobile autoplay remain subject to browser and video-owner restrictions. Keep the `strict-origin-when-cross-origin` referrer policy.
